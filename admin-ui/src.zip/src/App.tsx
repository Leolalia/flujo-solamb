﻿import "./App.css";
import OperationView from "./features/operation/OperationView";

export default function App() {
  return (
    <div className="app-root">
      <OperationView />
    </div>
  );
}
