export function getMode(): 'PRODUCTION' | 'SIMULATION' {
  return 'PRODUCTION';
}
