﻿export const EDGE_BASE_URL = "http://localhost:7788";
