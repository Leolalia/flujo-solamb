import { startHttpServer } from './http';

console.log('--- SOLAMB EDGE NODE (Walking Skeleton) ---');

startHttpServer(7789);
